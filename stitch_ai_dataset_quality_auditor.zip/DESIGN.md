---
name: Modern Analytical Precision
colors:
  surface: '#f9f9ff'
  surface-dim: '#d3daef'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3ff'
  surface-container: '#e9edff'
  surface-container-high: '#e1e8fd'
  surface-container-highest: '#dce2f7'
  on-surface: '#141b2b'
  on-surface-variant: '#434655'
  inverse-surface: '#293040'
  inverse-on-surface: '#edf0ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#1d4ed8'
  on-secondary: '#ffffff'
  secondary-container: '#4069f2'
  on-secondary-container: '#fffbff'
  tertiary: '#943700'
  on-tertiary: '#ffffff'
  tertiary-container: '#bc4800'
  on-tertiary-container: '#ffede6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dce1ff'
  secondary-fixed-dim: '#b7c4ff'
  on-secondary-fixed: '#001551'
  on-secondary-fixed-variant: '#0039b5'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb596'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7d2d00'
  background: '#f9f9ff'
  on-background: '#141b2b'
  surface-variant: '#dce2f7'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.025em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  metric-value:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  caption:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system delivers an understated, high-efficiency dashboard environment engineered for data-dense analytics workflows. The emotional tone is deliberate, quiet, and trustworthy—mirroring the clarity and functional restraint found in best-in-class developer and financial tooling.

The aesthetic fuses modern minimalism with utilitarian SaaS ergonomics:
- **Quiet Canvas:** Interfaces prioritize analytical content over ornamental decoration. Whitespace behaves as an active structural element rather than passive filler.
- **Micro-tactility:** Surfaces rely on 1px neutral borders and microscopic ambient shadows rather than elevation layers or blur filters.
- **Signal-to-Noise Discipline:** Color exists purely to establish state, actionability, or metric directional trends; decorative illustrations and ambient gradients are strictly avoided.

## Colors

The palette establishes an ultra-clean, high-legibility canvas using calibrated neutral tones paired with a singular royal blue accent.

### Color Tokens & Roles

- **Canvas & Surfaces:**
  - `canvas-default`: `#ffffff` (Primary base canvas and card backgrounds)
  - `canvas-subtle`: `#f8f9fa` (Sidebars, secondary panels, and global application shell)
  - `canvas-muted`: `#f3f4f6` (Disabled states, table headers, and nested container backgrounds)
- **Text & Content:**
  - `text-primary`: `#111827` (Headings, primary metric values, core content)
  - `text-secondary`: `#4b5563` (Subheadings, standard table text, field labels)
  - `text-muted`: `#6b7280` (Meta descriptions, timestamp badges, placeholders)
- **Borders & Dividers:**
  - `border-subtle`: `#f3f4f6` (Inner row dividers, secondary card splits)
  - `border-default`: `#e5e7eb` (Structural borders, input fields, widget perimeters)
  - `border-strong`: `#d1d5db` (Interactive element hover boundaries, active tabs)
- **Brand & Action:**
  - `accent-primary`: `#2563eb` (Primary buttons, selected active states, key data series)
  - `accent-hover`: `#1d4ed8` (Button hover states, pressed link targets)
  - `accent-subtle`: `#eff6ff` (Active tab fills, selected row highlights)

## Typography

The type system is built on Inter to achieve optimal legibility across alphanumeric tables, continuous prose, and standalone metric cards. 

### Implementation Rules
- **Tabular Figures:** Always apply `font-feature-settings: "tnum" 1, "cv05" 1` across data tables, timestamps, and metric readouts to prevent horizontal layout shift during dynamic updates.
- **Weight Restraint:** Limit weights strictly to `400` (Body copy, descriptions), `500` (Labels, metadata, navigation items), and `600` (Headings, key figures). Never use ultra-bold or hairline weights.
- **Tracking:** Negative letter-spacing scales progressively up as font sizes exceed 20px, counteracting visual optical drift on wide display monitors.

## Layout & Spacing

The layout operates on a strict 8px incremental baseline grid with a 4px half-step used only for micro-spacing (such as icon-to-label gaps).

### Grid & Containers
- **Dashboard Shell:** A fixed-width navigation rail (240px desktop, collapsed 64px tablet) pairs with a fluid analytical canvas capped at an optimal maximum width of 1440px for analytical clarity.
- **Data Grid:** 12-column layout on desktop screens (>1024px) utilizing 24px (`1.5rem`) gutters. Collapses to 6 columns on tablet (768px - 1023px) and 1 column on mobile (<768px).
- **Metric Grids:** Standard layout utilizes 4 columns for single-row KPI overviews on screens >= 1200px, folding cleanly into a 2x2 grid on tablet and stacked vertical blocks on mobile.

### Vertical Rhythm
- Keep analytical cards consistent in interior padding: use `space-lg` (24px) for prominent analytics panels, and `space-md` (16px) for compact sidebar widgets.
- Row items inside dense data tables maintain a 40px fixed height with 8px vertical padding.

## Elevation & Depth

This design system avoids high-blur, colored, or dramatic drop shadows. Visual depth is established through micro-shadows, surface tone separation, and crisp hairline borders.

### Elevation Hierarchy
- **Level 0 (Flat Canvas):** `#f8f9fa` base background without borders or shadows.
- **Level 1 (Default Containers & Cards):** `#ffffff` surface, bounded by a 1px solid `#e5e7eb` border, paired with a subtle micro-shadow: `0 1px 2px 0 rgba(0, 0, 0, 0.04)`.
- **Level 2 (Dropdowns, Menus & Tooltips):** Floating popovers over `#ffffff` surfaces utilize a 1px solid `#e5e7eb` border combined with an ambient low-spread shadow: `0 4px 6px -1px rgba(0, 0, 0, 0.06), 0 2px 4px -2px rgba(0, 0, 0, 0.04)`.
- **Level 3 (Modals & Command Palettes):** `#ffffff` elevated container with 1px solid `#e5e7eb` and an ambient shadow: `0 10px 15px -3px rgba(0, 0, 0, 0.08), 0 4px 6px -4px rgba(0, 0, 0, 0.04)`. Accompanied by a transparent backdrop overlay: `rgba(17, 24, 39, 0.25)`.

## Shapes

The design language uses balanced, subtle rounded corners that preserve the crisp, modular precision of dashboard layouts.

- **Base Corner Radius (8px / `0.5rem`):** Applied systematically to buttons, form inputs, metric cards, analytical containers, dropdown surfaces, and table outer frames.
- **Small Corner Radius (4px / `0.25rem`):** Applied to internal items such as status tags, inline badges, checkboxes, segmented control pills, and tooltip containers.
- **Large Corner Radius (12px / `0.75rem`):** Reserved for larger application modals, dialog boxes, and slide-over drawer headers.
- **Pill Shape (`9999px`):** Used exclusively for compact count indicators and live-status presence dots.

## Components

### Buttons
- **Primary:** Solid `#2563eb` fill, `#ffffff` text, 8px radius, height 36px (compact) or 40px (default). Hover state deepens to `#1d4ed8`. Active state shifts down 1px with no outer glow.
- **Secondary / Outline:** `#ffffff` fill, `#111827` text, 1px `#e5e7eb` border, subtle shadow `0 1px 2px 0 rgba(0, 0, 0, 0.04)`. Hover transitions to `#f8f9fa` surface and `#d1d5db` border.
- **Tertiary / Ghost:** Transparent background, `#4b5563` text. Hover applies `#f3f4f6` fill with `#111827` text.

### Metric Cards (KPI Displays)
- Rendered on a pure white canvas (`#ffffff`) with a 1px `#e5e7eb` border and standard micro-shadow.
- Card padding set to 20px or 24px (`space-lg`).
- Contains a top row featuring a subdued category label (`label-sm`, `#6b7280`), a large primary metric figure (`metric-value`, `#111827`), followed by an inline indicator for percentage changes (+2.4% in neutral dark or restrained muted green).

### Data Tables
- Encased within an 8px rounded container with a perimeter border of `#e5e7eb`.
- **Header Row:** `#f8f9fa` surface fill, height 36px, typography set to `label-sm` with `#4b5563` color, separated by a 1px `#e5e7eb` bottom divider.
- **Body Rows:** `#ffffff` surface, minimum height 44px, bottom border 1px `#f3f4f6`. Hover shifts the row background smoothly to `#f8f9fa`.

### Form Inputs & Selectors
- Standard height: 36px. Pure white `#ffffff` fill with a crisp 1px `#e5e7eb` border.
- Text rendered in `body-md` (`#111827`) with placeholder values in `#6b7280`.
- **Focus State:** 1px border shift to `#2563eb` accompanied by a flat focus ring: `0 0 0 2px rgba(37, 99, 235, 0.15)`. No animated glow effects.

### Badges & Filter Chips
- Height 24px, 4px border radius.
- Default neutral chip: `#f3f4f6` background with `#4b5563` text.
- Active/selected filter chip: `#eff6ff` background, 1px `#2563eb` border, and `#1d4ed8` text.

### Checkboxes & Radios
- Size: 16px by 16px, 4px border radius for checkboxes, full circle for radios.
- Unchecked: `#ffffff` fill with 1px `#d1d5db` border.
- Checked: Solid `#2563eb` fill with a crisp white centered check icon or circular dot.